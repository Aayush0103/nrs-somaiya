document.write(`
<header id="header">
        <div class="container">

            <div id="logo" class="pull-left">
                <!-- Uncomment below if you prefer to use a text logo -->
                <!-- <h1><a href="#main">C<span>o</span>nf</a></h1>-->
                <a href="../index.html" class="scrollto"><img src="../assets/img/KJ-Logo.webp" alt="" title=""></a>
            </div>

            <nav id="nav-menu-container">
                <ul class="nav-menu">
                    <li class="menu-active"><a href="../index.html#intro">Home</a></li>
                    <li><a href="../index.html#about">About</a></li>
                    <li><a href="../index.html#events">Events</a></li>
                    <li><a href="../index.html#speakers">Guests</a></li>
                    <li><a href="../index.html#schedule">Schedule</a></li>
                    <li><a href="../events/retailmela.html">Retail Mela</a></li>
                    <li><a href="../index.html#gallery">Gallery</a></li>
                    <div>
                        <div id="nrslogo">
                            <!-- Uncomment below if you prefer to use a text logo -->
                            <!-- <h1><a href="#main">C<span>o</span>nf</a></h1>-->
                            <a href="../index.html#intro" class="scrollto"><img src="../assets/img/NRS-LOGO.webp" alt="" title=""></a>
                        </div>
                </ul>

            </nav>
            <!-- #nav-menu-container -->
            </div>
    </header>
`);